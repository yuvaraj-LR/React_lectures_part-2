const INITIAL_STATE = { message: null };

// create alert slice to handle start, pause, timer actions below

// export the alert reducer function here

// create and export alert selector function here
