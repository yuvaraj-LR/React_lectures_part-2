### Create action creators and a reducer function to handle states of a counter.

Define actions constants and action creators to implement increment, decrement and reset counter functionality.

Create and export a counter reducer function to manage these state of a simple counter.

Combine the timer and counter reducer functions and add them inside the Redux store.

Dispatch actions to increment, decrement and reset the counter.

Expected Output:
<img src="https://files.codingninjas.in/multireducer-26618.gif"/>
