// add counter action creators imports here

const INITIAL_STATE = { count: 0 };

// define counter reducer function here
export const counterReducer = () => INITIAL_STATE;
