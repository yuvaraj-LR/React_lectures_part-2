// create post context here

// Create custom hook that returns context value here

// create a custom saved post provider here with add and reset functions
