### Debug the React app to use pre-defined routes with React Router.

Fix the code to define and create routes for the Home, List and Contact pages with React Router.
