### Refactor the React app to display the NotFound page for unhandled routes.

Show the NotFound page for all the routes that are not defined inside the app.

Clicking on the back button inside the NotFound page should navigate user back to the Home page.

Output:
<img src="https://files.codingninjas.in/not-found-26220.gif" />
