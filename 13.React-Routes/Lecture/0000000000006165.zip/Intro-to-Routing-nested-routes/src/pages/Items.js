function Items() {
  return (
    <>
      <main>
        <h1>Items Page</h1>
      </main>
    </>
  );
}

export default Items;
